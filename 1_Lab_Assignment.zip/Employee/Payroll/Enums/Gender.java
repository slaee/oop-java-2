package Payroll.Enums;

public enum Gender{
    MALE,
    FEMALE
}